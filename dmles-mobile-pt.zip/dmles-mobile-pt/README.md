Ionic 2 App Base
=====================

This is the base template for Ionic 2 starter apps.

## Using this project

You'll need the Ionic CLI with support for v2 apps:

```bash
$ npm install -g ionic
```

Then run:

```bash
$ ionic start myApp
```

More info on this can be found on the Ionic [Getting Started](http://ionicframework.com/docs/v2/getting-started/) page.

DMLES-MOBILE Read me

Install Cordova
npm install -g cordova
Install Ionic
npm install -g ionic
git clone //jwsrv110/Public/"Software Engineering/Mobility"/Repo/dmles-mobile-pt
cd to cloned directory
npm install
ionic serve 
OR
ionic serve –lab
If you get the following on serve: express deprecated res.sendfile: Use res.sendFile instead node_modules\@ionic\app-scripts\dist\dev-server\http-server.js:26:20
Simply go to the file at the line number and change the case of ‘res.sendfile’ to ‘res.sendFile’
 Android:
ionic build android
ionic run android 

Generating code:
ionic generate [ex provider] [classname ex. todoservice] // generator for typescript / angular classes
ionic OR
ionic g [ex provider] [classname ex. todoservice]
// class types available [case is important]
component
directive
page
pipe
provider
tabs

Ionic @ Components
http://ionicframework.com/docs/v2/components/#overview
This page doesn’t consistently work in Chrome for me but Firefox does work (haven’t tried IE)

I'm assuming the device would need to store images but it might be better to get them from a source as 64bit strings…???). 

Testing is still a work in progress, there ways to make it work but it is a pain right now.

Josh Maroney has a few tutorials on Ionic 2; they are ok. Here’s one: http://www.joshmorony.com/a-simple-guide-to-navigation-in-ionic-2/
 

