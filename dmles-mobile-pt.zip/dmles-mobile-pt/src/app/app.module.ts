import { NgModule, ErrorHandler } from '@angular/core';
import { IonicApp, IonicModule, IonicErrorHandler } from 'ionic-angular';

import { InMemoryWebApiModule } from 'angular-in-memory-web-api';
import { InMemoryDataService } from '../providers/in-memory-data-service';

import { MyApp } from './app.component';
import { HomePage } from '../pages/home/home';
import { Login } from '../pages/login/login';

import { HttpModule } from '@angular/http';

import { NotificationService } from "../providers/notification-service";
import { SupplyItemService } from "../providers/supply-item-service";
import { OrderService } from "../providers/order-service";
import { IssueService } from "../providers/issue-service";
import { SupplyItemSearchService } from "../providers/supply-item-search-service";
 
import { AppNav } from './appNav.component';
import { AppContainer } from './app-container';

import { Notifications } from '../pages/notifications/notifications';
import { Orders } from '../pages/orders/orders';
import { SupplyItems } from '../pages/supplyItems/supplyItems';
import { Issues } from  '../pages/issues/issues';
import { Inventory } from "../pages/inventory/inventory";
import { ImReceipts } from '../pages/inventory/imReceipts';
import { Caim } from '../pages/inventory/caim';
import { Etm } from '../pages/inventory/etm';
import { AddSupplyItemComponent } from '../pages/supplyItems/add-supply-item/add-supply-item';
import { OrderDetailComponent } from '../pages/orders/order-detail/order-detail';
import { SupplyItemSearchComponent } from '../pages/supplyItems/supply-item-search/supply-item-search';
import { AddOrderComponent } from '../pages/orders/add-order/add-order';



@NgModule({
  declarations: [
    MyApp,
    AppNav,
    AppContainer,
    HomePage,
    Login,
    Notifications,
    Orders,
    SupplyItems,
    Issues,
    Inventory,
    ImReceipts,
    Caim,
    Etm, 
    AddSupplyItemComponent,
    SupplyItemSearchComponent,
    OrderDetailComponent,
    AddOrderComponent    
  ],
  imports: [
    IonicModule.forRoot(MyApp),
    HttpModule,
    InMemoryWebApiModule.forRoot(InMemoryDataService),

  ],
  bootstrap: [IonicApp],
  entryComponents: [
    MyApp,
    AppNav,
    AppContainer,
    HomePage,
    Login,
    Orders,
    Notifications,
    SupplyItems,
    Issues,
    Inventory,
    ImReceipts,
    Caim,
    Etm,
    AddSupplyItemComponent,
    SupplyItemSearchComponent,
    OrderDetailComponent,
    AddOrderComponent
  ],
  providers: [{ provide: ErrorHandler, useClass: IonicErrorHandler },
    NotificationService,
    OrderService,
    SupplyItemService,
    SupplyItemSearchService,
    IssueService]
})
export class AppModule { }
