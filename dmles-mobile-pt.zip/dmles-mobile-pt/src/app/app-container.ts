import { Component } from '@angular/core';
//import { Nav } from 'ionic-angular';

import { AppNav } from './appNav.component';

@Component( {
    templateUrl: 'app-container.html'
})
export class AppContainer {

   menuRootPage: any = AppNav; 


   logOut() {

   }

   ionViewLoaded(): void { 
    //this.nav.setRoot(this.pages[0]);
  }


}

