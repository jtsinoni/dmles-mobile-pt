import { Component, ViewChild } from '@angular/core';
import { Nav } from 'ionic-angular';

import { Notifications } from '../pages/notifications/notifications';
import { Orders } from '../pages/orders/orders';
import { SupplyItems } from '../pages/supplyItems/supplyItems';
import { Inventory } from '../pages/inventory/inventory';
import { Issues } from  '../pages/issues/issues';
//import {MyApp} from './app.component'; 


@Component( {
    templateUrl: 'appNav.html'
})
export class AppNav {
   @ViewChild(Nav) nav: Nav;
   rootPage: any = Notifications;

  pages: Array<{ title: string, component: any }>; 

  constructor() {    

    this.pages = [
      { title: 'My Notifications', component: Notifications },
      { title: 'My Orders', component: Orders },
      { title: 'My Supply Items', component: SupplyItems },
      { title: 'My Issued Items', component: Issues },
      { title: 'Inventory', component: Inventory }
    ];  

    

  }

  ionViewLoaded(): void { 
    this.nav.setRoot(this.pages[0]);
  }

  openPage(page) { 
    //this.menuCtrl.close();
    this.nav.setRoot(page.component);
  }

  logOut() {
    //this.myApp.logOut();
  }
}