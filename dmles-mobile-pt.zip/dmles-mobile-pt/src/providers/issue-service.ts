import { Injectable } from '@angular/core';
import { Http } from '@angular/http';
import 'rxjs/add/operator/map';

import { ApiService } from './api-service';

import { Issue } from '../pages/issues/issue';

/*
  Generated class for the IssueService provider.

  See https://angular.io/docs/ts/latest/guide/dependency-injection.html
  for more info on providers and Angular 2 DI.
*/
@Injectable()
export class IssueService extends ApiService<Issue, string> {

  constructor(public http: Http) {

    super(http, 'providers/issues');
  }

  getAllIssues(): Promise<Array<Issue>> {
    return this.getMany();
  }

  getIssue(id: string) {
    return this.getOne(id);
  }

}
