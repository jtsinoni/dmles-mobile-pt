import { Injectable } from '@angular/core';
import { Http } from '@angular/http';
import { ApiService } from './api-service';
import { SupplyItem } from '../pages/supplyItems/supplyItem';

/*
  Generated class for the SupplyItemService provider.

  See https://angular.io/docs/ts/latest/guide/dependency-injection.html
  for more info on providers and Angular 2 DI.
*/
@Injectable()
export class SupplyItemService extends ApiService<SupplyItem, string> {

  //private supplyItemsUrl = 'pages/supplyItems';



  constructor(public http: Http) {
    super (http, 'providers/supplyItems');
  }

   getAllSupplyItems() : Promise<SupplyItem[]> {
     return this.getMany();

   }

   createSupplyItem (supplyItem: SupplyItem) : Promise<SupplyItem> {
      return this.create(supplyItem);

   } 

   getSupplyItem(id:string) : Promise<SupplyItem> {
     return this.getOne(id);
   } 



}
