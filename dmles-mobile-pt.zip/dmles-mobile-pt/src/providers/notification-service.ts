import { Injectable } from '@angular/core';
import { Http } from '@angular/http';

import { Notification } from "../pages/notifications/notification";
import { ApiService } from './api-service';

/*
  Generated class for the NotificationService provider.

  See https://angular.io/docs/ts/latest/guide/dependency-injection.html
  for more info on providers and Angular 2 DI.
*/
@Injectable()
export class NotificationService extends ApiService<Notification, number> {

  //notifications: Array<Notification>;

  //notification: Notification;

  constructor(http: Http) {
    // TODO get - set url
    super(http, 'providers/notifications');

    // TODO remove
    // if (!this.notifications) {
    //   this.notifications = new Array<Notification>();

    //   this.loadFakeNotifications();
    // }
  }


  getNotifications():  Promise<Notification[]> {
     return this.getMany();
  }

  getNotification(id: number):  Promise<Notification> {
    return this.getOne(id);
  }

  deleteNotification(id: number): Promise<void> {
    return this.delete(id);
  }

}
