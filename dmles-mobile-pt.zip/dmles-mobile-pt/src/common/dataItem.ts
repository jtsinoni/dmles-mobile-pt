export class DataItem<K> {
    id: K;
}