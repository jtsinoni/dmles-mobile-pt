import { Component } from '@angular/core';

import { NavController, NavParams, ActionSheetController, Platform } from 'ionic-angular';

import { Issue } from './issue';

import { IssueService } from '../../providers/issue-service';

@Component({
  selector: 'page-issues',
  templateUrl: 'issues.html'
})
export class Issues {

public issuesList: Array<Issue>;

   constructor(public navCtrl: NavController,
    navParams: NavParams,
    public issueService: IssueService,
    public actionSheetController: ActionSheetController,
    public platform: Platform) {

  }
  
   ionViewWillEnter() {
    this.getIssues();

  }

  getIssues() {
    this.issueService.getAllIssues().then(issues => this.issuesList = issues);

  }

    issueSelected($event, issue) {
    let options = this.actionSheetController.create({
      buttons: [
        {
          text: 'Show Detail',
          role: 'all',
          handler: () => {
            //todo show detail
          }
        },
        {
          text: 'Approve',
          role: 'approval',
          handler: () => {
            //todo --- got no idea...something or something else...
          }
        },
        {
          text: 'Close',
          role: 'close',
          icon: !this.platform.is('ios') ? 'close' : null,
          handler: () => {
            console.log('Close clicked');
          }
        }
      ]
    });
    options.present();

  }






}