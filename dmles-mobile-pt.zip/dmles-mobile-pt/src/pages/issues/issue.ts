'use strict';

import { DataItem } from '../../common/dataItem';

export class Issue extends DataItem<string> {
    documentNumber: string;
    itemId: string;
    issueDate: Date;
    issueState: number;
    quantityIssued: number;
    requestor: string;
    id: string = this.documentNumber;

}