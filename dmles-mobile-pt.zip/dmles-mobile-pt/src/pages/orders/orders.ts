import { Component } from '@angular/core';

import { NavController, NavParams, ActionSheetController, Platform, ModalController } from 'ionic-angular';

import { Order } from './order';

import { OrderDetailComponent } from './order-detail/order-detail';

import { OrderService } from '../../providers/order-service';

@Component({
  selector: 'page-orders',
  templateUrl: 'orders.html'
})
export class Orders {

  public ordersList: Array<Order>;

  constructor(public navCtrl: NavController,
    navParams: NavParams,
    public orderService: OrderService,
    public modalController: ModalController, 
    public actionSheetController: ActionSheetController,
    public platform: Platform) {

  }

  ionViewWillEnter() {
    this.getOrders();

  }

  getOrders() {
    this.orderService.getAllOrders().then(orders => this.ordersList = orders);

  }

  orderSelected(order) {  

    let options = this.actionSheetController.create({
      buttons: [
        {
          text: 'Get Status',
          role: 'status',
          handler: () => {
            //todo update Status
          }
        },
        {
          text: 'Receive',
          role: 'receipt',
          handler: () => {
            //todo process receipt
          }
        },
         {
          text: 'Detail',
          role: 'all',
          handler: () => {
            if (order) {            
              this.presentDetailModal(order);
            } 
          }
        },
        {
          text: 'Close',
          role: 'close',
          icon: !this.platform.is('ios') ? 'close' : null,
          handler: () => {
            console.log('Close clicked');
          }
        }
      ]
    });
    options.present();

  }

  presentDetailModal(order: Order) {
    let detailModal = this.modalController.create(OrderDetailComponent, { orderItem: order});
    detailModal.present();
  }

}