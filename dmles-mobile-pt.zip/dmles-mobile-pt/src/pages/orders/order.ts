'use strict';

import { DataItem } from '../../common/dataItem';

export class Order extends DataItem<string> {
    public documentNumber: string;
    public orderQuantity: number;
    public itemId: string;
    public unitOfPurchasePrice: number;
    public orderDate: Date;
    public requiredDate: Date;
    public requestor: string;
    public orderState: number;
    id:string; 

}