export class User {
    username: string;
    password: string;
    myServer: string;

    constructor () {
        // todo get the server from someplace
        this.myServer = "JWDEV102";
    }
}