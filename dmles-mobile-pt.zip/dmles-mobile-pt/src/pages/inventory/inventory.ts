import { Component } from '@angular/core';

import { NavController } from 'ionic-angular';

import { ImReceipts } from './imReceipts';
import { Caim } from './caim';
import { Etm } from './etm';


@Component({
  selector: 'inventory-inventory',
  templateUrl: 'inventory.html'
})

export class Inventory {

    tab1Root: any = ImReceipts;
    tab2Root: any = Caim;
    tab3Root: any = Etm;

    constructor(navCtrl: NavController) {

        


    }
}
