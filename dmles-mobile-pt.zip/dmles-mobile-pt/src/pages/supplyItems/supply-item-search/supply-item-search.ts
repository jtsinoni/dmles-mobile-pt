import { Component } from '@angular/core';
import { SupplyItem } from '../supplyItem';

import { Observable } from 'rxjs/Observable';
import { Subject } from 'rxjs/Subject';

import { SupplyItemSearchService } from '../../../providers/supply-item-search-service';
/*
  Generated class for the SupplyItemSearchComponent component.

  See https://angular.io/docs/ts/latest/api/core/index/ComponentMetadata-class.html
  for more info on Angular 2 Components.
*/
@Component({

  selector: 'supply-item-search',
  templateUrl: 'supply-item-search.html',
  providers: [SupplyItemSearchService]
})
export class SupplyItemSearchComponent {

  supplyItems: Observable<Array<SupplyItem>>;

  private searchTerms = new Subject<string>();

  supplyItem: SupplyItem;

  searchTerm: string;

  constructor(private supplyItemSearchService: SupplyItemSearchService) {
    this.searchTerm ='';

  }

  search(searchTerm: string): void {
    this.searchTerms.next(searchTerm);
  }

  ionViewWillEnter() {
    this.supplyItems = this.searchTerms
      .debounceTime(300)
      .distinctUntilChanged()
      .switchMap(searchTerm => searchTerm
        ? this.supplyItemSearchService.search(searchTerm) :
        Observable.of<Array<SupplyItem>>([])).catch(error => {
          console.log(error);
          return Observable.of<Array<SupplyItem>>([]);
        });

  }

  showItemDetail(item: SupplyItem) {
    // do something
  }

}
