import { Component } from '@angular/core';

import { NavController, NavParams, AlertController, ModalController, ActionSheetController, Platform } from 'ionic-angular';

import { SupplyItem } from './supplyItem';

import { SupplyItemService } from '../../providers/supply-item-service';

import { AddOrderComponent } from '../orders/add-order/add-order';

import { Search } from "../../common/search";
import { LoadingController } from 'ionic-angular';

@Component({
  selector: 'page-supplyItems',
  templateUrl: 'supplyItems.html'
})
export class SupplyItems extends Search {

  public supplyItemList: Array<SupplyItem>;

  constructor(public navCtrl: NavController,
    navParams: NavParams,
    public supplyItemService: SupplyItemService,
    public alertController: AlertController, 
    public loadingController: LoadingController,
    public modalController: ModalController,
    public actionSheetController: ActionSheetController,
    public platform: Platform) {
    super(loadingController);

  }

  ionViewWillEnter() {
    this.getSupplyItems();

  }

  showFindItem() {
    let alert = this.alertController.create({
      title: "Find",
      message: 'Enter an item description',
      inputs: [
        {
          name: 'value',
          placeholder: 'Item Desc'
        }
      ],
      buttons: [
        {
          text: 'Cancel',
          handler: data => {
            console.log('Cancel clicked');
          }
        },
        {
          text: 'Go',
          handler: data => {
            console.log('Go clicked');
            this.showLoadingData(data.value);
          }
        }
      ]

    });
    alert.present();

  }

  getSupplyItems() {
    this.supplyItemService.getAllSupplyItems().then(supplyItems => this.supplyItemList = supplyItems);
  }

  itemSelected(item) {  

    let options = this.actionSheetController.create({
      buttons: [
        {
          text: 'Order',
          role: 'order',
          handler: () => {
            this.orderItem(item);
          }
        },    
         {
          text: 'Detail',
          role: 'all',
          handler: () => {
            if (item) {            
              this.showItemDetail(item);
            } 
          }
        },
        {
          text: 'Cancel',
          role: 'all',
          icon: !this.platform.is('ios') ? 'close' : null,
          handler: () => {
            console.log('Close clicked');
          }
        }
      ]
    });
    options.present();

  }

  orderItem(item : SupplyItem) {
    let orderModal = this.modalController.create(AddOrderComponent, { supplyItem: item});
    orderModal.present();

  }

  
  showItemDetail(item : SupplyItem) {
     

  }

  showImageDetail(url: string) {
    //  let detailModal = this.modalController.create();
    // detailModal.present();
  }   
  
}