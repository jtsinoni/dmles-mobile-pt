'use strict';

import { DataItem } from '../../common/dataItem';

export class SupplyItem extends DataItem<string> {

    public itemId : string;
    public itemDescription: string;
    public unitOfPurchasePrice: number;
    public onHandBalance: number;
    id:string = this.itemId; 
    imgUrl: string;

}