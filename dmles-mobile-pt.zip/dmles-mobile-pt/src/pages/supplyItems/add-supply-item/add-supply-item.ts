import { Component } from '@angular/core';
import { SupplyItem } from '../supplyItem';

import { SupplyItemService } from '../../../providers/supply-item-service';

/*
  Generated class for the AddSupplyItem component.

  See https://angular.io/docs/ts/latest/api/core/index/ComponentMetadata-class.html
  for more info on Angular 2 Components.
*/
@Component({
  selector: 'add-supply-item',
  templateUrl: 'add-supply-item.html'
})
export class AddSupplyItemComponent {

  supplyItem: SupplyItem;

  constructor(public supplyItemService: SupplyItemService) {    
  }

   ionViewLoaded() { 
     this.supplyItem = new SupplyItem();
   }

   createNewSupplyItem() {
     this.supplyItemService.createSupplyItem(this.supplyItem);
   }

}
