import { DataItem } from '../../common/dataItem';

export class Notification extends DataItem<number> {
    id: number;
    title: string;
    message: string;
    noticeType: number;

}