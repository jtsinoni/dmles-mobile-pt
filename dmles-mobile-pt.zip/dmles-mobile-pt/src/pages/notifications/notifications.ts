import { Component } from '@angular/core';

import { NavController } from 'ionic-angular';

import { Notification } from './notification';

import { NotificationService } from "../../providers/notification-service";


@Component({
  selector: 'notifications-notifications',
  templateUrl: 'notifications.html'
})

export class Notifications {

  notifications = new Array<Notification>();

  constructor(public navController: NavController, public notificationService: NotificationService) {   

  }

  ionViewWillEnter() {
     this.getNotifications();
  }

  getNotifications() {
    this.notificationService.getNotifications().then(n => this.notifications = n);
  }

  notificationSelected(event, notice) {
    // todo something with the notification - go to, go there, see details...?
  }

  notificationSwiped(event, notice) {
    this.notificationService.delete(notice.id);
    this.getNotifications();   
  }

  addNotification(notice) {
    //this.notificationService.addNotification(notice);
  }


}
