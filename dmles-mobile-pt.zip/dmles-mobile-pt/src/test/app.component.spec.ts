/* tslint:disable:no-unused-variable */
import { MyApp } from '../app/app.component';
//import { AppRoutingModule } from './app-routing.module';


import { By }           from '@angular/platform-browser';
import { DebugElement } from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { } from 'jasmine';

////////  SPECS  /////////////
describe('MyApp', function () {
  let de: DebugElement;
  let comp: MyApp;
  let fixture: ComponentFixture<MyApp>;

  beforeEach(async(() => {
   
   TestBed.configureTestingModule({
      imports: [
      MyApp
    ],
      declarations: [ MyApp ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MyApp);
    comp = fixture.componentInstance;
    de = fixture.debugElement.query(By.css('ion-nav'));
  });

  it('should create component', () => expect(comp).toBeDefined() );

  // it('should have expected <h1> text', () => {
  //   fixture.detectChanges();
  //   const h1 = de.nativeElement;
  //   expect(h1.innerText).toMatch(/tour of heroes/i,
  //     '<h1> should say something about "Tour"');
  // });
});
